import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailb',
  templateUrl: './detailb.page.html',
  styleUrls: ['./detailb.page.scss'],
})
export class DetailbPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
